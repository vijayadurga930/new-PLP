package com.capg.bank.service;

import java.util.ArrayList;

import com.capg.bank.bean.BankBean;

public interface IBankService {
	BankBean addAccount(BankBean bean);
	BankBean getAccountBalence(int account_id);
	BankBean deposit(int account_id, double amount);
	BankBean withdraw(int account_id, double amount);
	BankBean fundTransfer(int account_id1,int account_id2, double amount);
	ArrayList printDetails(int account_id);
}
