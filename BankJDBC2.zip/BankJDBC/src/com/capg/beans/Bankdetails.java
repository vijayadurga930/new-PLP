package com.capg.beans;

public class Bankdetails {
	private String accountNum;
	private String username;
	private String password;
	private String name;
	private String mobile;
	private String Address;
	private double balance;
	
	public Bankdetails() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Bankdetails(String accountNum,String username,String password ,String name, String mobile, String address, double balance
			) {
		super();
		this.accountNum = accountNum;
		this.name = name;
		this.mobile = mobile;
		this.Address = address;
		this.balance = balance;
		this.username=username;
		this.password=password;
	}
	
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getAccountNum() {
		return accountNum;
	}
	public void setAccountNum(String accountNum) {
		this.accountNum = accountNum;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getMobile() {
		return mobile;
	}
	public void setMobile(String mobile) {
		this.mobile = mobile;
	}
	public String getAddress() {
		return Address;
	}
	public void setAddress(String address) {
		Address = address;
	}
	public double getBalance() {
		return balance;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}
	@Override
	public String toString() {
		return "Bankdetails [accountNum=" + accountNum + ", name=" + name + ", mobile=" + mobile + ", Address="
				+ Address + ", balance=" + balance + ", username=" + username + ", password=" + password + "]";
	}
	


}
