package com.capg.beans;

public class Transaction {
	private double amount;
	private double balance;
	private String date;
	private String details;
	private int transcationId;
	public Transaction(double amount, double balance, String date, String details,int transactionId) {
		super();
		this.amount = amount;
		this.balance = balance;
		this.date = date;
		this.details = details;
		this.transcationId = transcationId;
	}
	public Transaction() {
		super();
		// TODO Auto-generated constructor stub
	}
	public double getAmount() {
		return amount;
	}
	public void setAmount(double amount) {
		this.amount = amount;
	}
	public double getBalance() {
		return balance;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	public String getDetails() {
		return details;
	}
	public void setDetails(String details) {
		this.details = details;
	}
	public int getTranscationId() {
		return transcationId;
	}
	public void setTranscationId(int transcationId) {
		this.transcationId = transcationId;
	}
	@Override
	public String toString() {
		return "Transaction [amount=" + amount + ", balance=" + balance + ", date=" + date + ", details=" + details
				+ ", transcationId=" + transcationId + "]";
	}

}
