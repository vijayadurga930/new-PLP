package com.capg.service;

import java.util.List;

import com.capg.beans.Bankdetails;
import com.capg.beans.Transaction;
import com.capg.exception.BankException;

public interface IBankservice {

public int accountNo();
	

	
	public boolean isPhonevalid(String phone)throws BankException;
	public boolean isNamevalid(String name)throws BankException;
	
	int addTransact(Transaction transact, String account);
	List<Transaction> printAllTransactions(String AccoutnNo);
	boolean addCustomer(Bankdetails banking);
	double balance(String accountNo);



	boolean details(String string, double amount, String accountNo2);
	
}
