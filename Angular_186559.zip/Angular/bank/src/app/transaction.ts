

export class Transaction {
	
	transactionId: number;
	creditedAmount: number;
	debitedAmount: number;
	balance: number;
	accNo: number;
}
