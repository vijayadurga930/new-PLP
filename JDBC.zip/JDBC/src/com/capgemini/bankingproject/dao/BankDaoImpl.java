package com.capgemini.bankingproject.dao;




import java.util.List;
import java.util.Map;

import com.capgemini.bankingproject.bean.Customers;
import com.capgemini.bankingproject.bean.Transaction;
import com.capgemini.bankingproject.exception.BankException;


public class BankDaoImpl implements IBankDao {

	


	@Override
	public long addToCustomer(Customers customer) throws BankException {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public void showBalance(int custId) throws BankException {
		Customers bean=new Customers();
		double balance = 0;
			balance = bean.getBalance();
		}
		
	

	@Override
	public int transferFunds(Transaction transaction, int sourceCustId, int destinationCustId) throws BankException {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public void depositBalance(int custId, double amount) throws BankException {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void withdrawBalance(int custId, double amount) throws BankException {
		// TODO Auto-generated method stub
		
	}

	@Override
	public Map<Integer, Transaction> printTransactionDetails(int transId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Customers> insertCustomer(Customers customer) throws BankException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Customers> viewAll(Customers customer) throws BankException {
		// TODO Auto-generated method stub
		return null;
	}

	public static Map<Integer, Customers> getCustomerList() {
		// TODO Auto-generated method stub
		return null;
	}

	public static Map<Integer, Transaction>getTransactionList() {
		// TODO Auto-generated method stub
		return null;
	}

		}
	

	

	
	

