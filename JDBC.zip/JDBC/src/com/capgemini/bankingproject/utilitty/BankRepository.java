package com.capgemini.bankingproject.utilitty;

public class BankRepository {

}
