package com.capgemini.bankingproject.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.capgemini.bankingproject.bean.Customers;
import com.capgemini.bankingproject.bean.Transaction;
import com.capgemini.bankingproject.exception.BankException;

public interface IBankService {

	public static Map<Integer, Customers> customerList = new HashMap<>();
	
	public boolean custNameValidation(String name) throws BankException;
	public boolean custMobValidation(String mobile) throws BankException;
	public boolean custEmailValidation(String email)throws BankException;
	public long addToCustomer(Customers customer) throws BankException;
	public boolean validateDestinationAccount(int custId) throws BankException;
	public int transferFunds(Transaction transaction,int sourceCustId,int destinationCustId) throws BankException;
	void showBalance(int custId) throws BankException;
	public void depositBalance(int custId,double amount) throws BankException;
	public void withdrawBalance(int custId, double amount)throws BankException;
	public boolean validateTransactionId(int transId)throws BankException;
	public Map<Integer, Transaction> printTransactionDetails(int transId) throws BankException;
	public List<Customers> insertCustomer(Customers customer)throws BankException;
	public List<Customers> viewAll(Customers customer)throws BankException;

	
	
}
