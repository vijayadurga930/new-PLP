

export class Bank {
	
	accNo: number;
	accHolder: string;
	balance: number;
	
}
