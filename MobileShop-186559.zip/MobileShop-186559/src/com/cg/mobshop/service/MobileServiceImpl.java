package com.cg.mobshop.service;

import java.util.List;
import com.cg.mobshop.dto.Mobiles;
import com.cg.mobshop.dao.MobileDAO;
import com.cg.mobshop.dao.MobileDAOImpl;
/**
 * 
 * @author vijsimha writing implementations 
 * for methods which are declared in service interface.
 *
 */

public class MobileServiceImpl implements MobileService {
   MobileDAO dao=new MobileDAOImpl();

@Override
public List<Mobiles> getAllDetails() {

	return dao.getAllDetails();
}

@Override
public boolean delete(int mobileId) {
	boolean status=dao.deleteMobile( mobileId);
	if(status=true) {
		
		status=true;
	}
	
	
	return status;
}


	


@Override
public List<Mobiles> getNewDetails(int mobileId) {
	
	return dao.getNewDetails(mobileId);
}
}
	
	

