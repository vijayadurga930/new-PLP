package com.cg.mobshop.service;

import java.util.List;

import com.cg.mobshop.dto.Mobiles;
/**
 * 
 * @author vijsimha writing methods in service interface which are implemented 
 * service implementation layer.
 *
 */

public interface MobileService {

	List<Mobiles> getAllDetails();

	boolean delete(int mobileId);

	List<Mobiles> getNewDetails(int mobileId);


}
