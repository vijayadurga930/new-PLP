package com.cg.mobshop.sort;

import java.util.Comparator;

import com.cg.mobshop.dto.Mobiles;

public class SortByName implements Comparator<Mobiles>{

	@Override
	public int compare(Mobiles m1, Mobiles m2) {
		
		return m1.getName().compareTo(m2.getName());
	}

}
