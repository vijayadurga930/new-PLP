package com.cg.mobshop.sort;

import java.util.Comparator;

import com.cg.mobshop.dto.Mobiles;

public class SortByPrice  implements Comparator<Mobiles>{

	@Override
	public int compare(Mobiles m1, Mobiles m2) {
		if(m1.getPrice()>m2.getPrice()) {
			return 1;
		}else if(m1.getPrice()<m2.getPrice()){
			return -1;
		}else
		
		return 0;
	}

}
