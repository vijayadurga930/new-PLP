package com.cg.mobshop.dao;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Map;

import com.cg.mobshop.dto.Mobiles;
import com.cg.mobshop.exception.MobileException;
import com.cg.mobshop.util.Util;
/**
 * 
 * @author vijsimha writing implementations 
 * for methods which are declared in DAO interface.
 *
 */

public class MobileDAOImpl implements MobileDAO {
 Util repo=new Util();
 boolean status=false;
	@Override
	public List<Mobiles> getAllDetails() {
		
		Map<Integer, Mobiles> map = repo.getMobileEntries();
		
		Collection<Mobiles> collection=map.values();
		
		List<Mobiles> mobilelist=new ArrayList<>();
		
		mobilelist.addAll(collection);
		
		Collections.sort(mobilelist);
		
		return mobilelist;
	}

	@Override
	public boolean deleteMobile(int mobileId) {
		
Map<Integer, Mobiles> map = repo.getMobileEntries();
		
Mobiles mobile = map.remove(mobileId);
		if(map.get(mobileId)!=null)
		{
			
			System.out.println(map);
			status=true;
		}
		else {
			
			status=false;
		}
		    return status;
	}

	@Override
	public List<Mobiles> getNewDetails(int mobileId) {
		boolean IDFlag=false;
		Map<Integer,Mobiles> mobilelist=Util.getMobileEntries();
		if(mobilelist.containsKey(mobileId)) {
	
		mobilelist.remove(mobileId);
		IDFlag=true;
		}
		else {
			try {
				throw new MobileException ("id not exists");
			}catch(MobileException e) {
				System.out.println(e.getMessage());
			}
		}
		Collection<Mobiles> collection=mobilelist.values();
		List<Mobiles> mobiles=new ArrayList<>();
		mobiles.addAll(collection);
		return mobiles;
		
		
	}
	
	

}
