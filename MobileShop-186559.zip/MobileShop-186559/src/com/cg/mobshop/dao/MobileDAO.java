package com.cg.mobshop.dao;

import java.util.List;

import com.cg.mobshop.dto.Mobiles;
/**
 * 
 * @author vijsimha  writing methods in dao interface which are implemented 
 * dao implementation layer.
 *
 */


public interface MobileDAO {

	List<Mobiles> getAllDetails();

	
	boolean deleteMobile(int mobileId);

	List<Mobiles> getNewDetails(int mobileId);

}
