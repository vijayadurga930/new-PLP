package com.cg.mobshop.ui;

import java.util.Collections;
import java.util.List;
import java.util.Scanner;

import com.cg.mobshop.dto.Mobiles;
import com.cg.mobshop.service.MobileService;
import com.cg.mobshop.service.MobileServiceImpl;
import com.cg.mobshop.sort.SortById;
import com.cg.mobshop.sort.SortByName;
import com.cg.mobshop.sort.SortByPrice;

public class MainUI {
	static String value;
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		MobileService service=new MobileServiceImpl();
		/**
		 * @author vijsimha
		 * @version 1.0
		 * 
		 * initializing flags and values.   
		 */
		
			boolean choice=false;
			boolean result=false;
			boolean deleteFlag=false;
			int option;
			String choice2;  
			int choiceoption = 0;
  do {
	    			 /**
	    			  * writing sub-menu for sorting after selecting sorting, 
	    			  * it displays sorting menus
	    			  */
	System.out.println("**WELCOME TO MOBILE SHOPEE***");
    System.out.println("1.Sorting\n2.deletion \n 3. exit");
    System.out.println(service.getAllDetails());
	choice=true;
	option=scanner.nextInt();
	switch (option) {
	case 1:{

				System.out.println("Enter Option \n1.Sort by MobileName \n2.Sort byMobilePrice \n3.Sort byMobileId ");
				  int option2=scanner.nextInt();
				  switch(option2) {

			 		case 1:{
			 			List<Mobiles> Mobilelistbyname=service.getAllDetails();
			 			Collections.sort(Mobilelistbyname, new SortByName());
						System.out.println(Mobilelistbyname);
			 		}
					break;
			 		case 2:{
			 			List<Mobiles> Mobilelistbyprice=service.getAllDetails();
			 			Collections.sort(Mobilelistbyprice, new SortByPrice());
			 			System.out.println(Mobilelistbyprice);
			 		}break;
			 		case 3:{
			 			List<Mobiles> Mobilelistbyid=service.getAllDetails();
			 			Collections.sort(Mobilelistbyid, new SortById());
			 			System.out.println(Mobilelistbyid);
			 		}break;
		}break;
	}
	case 2:{
		do {
			System.out.println("Enter employee Id to delete");
		scanner=new Scanner(System.in);
          int mobileId=scanner.nextInt();
      	boolean status=service.delete(mobileId);
      	List<Mobiles> deleteMobilelist=service.getNewDetails(mobileId);
		if(status=true)
		{
			System.out.println( mobileId+ "  Deleted Successfully......");
			deleteFlag=true;
			System.out.println(deleteMobilelist);
		}else {
			System.out.println("Id not available...");
			
		}
			
	}while(!deleteFlag);
	}break;
	case 3:{
		System.out.println("Thanks for visiting");
		System.exit(0);
	}break;
	default:
	{
		System.out.println("enter options only from 1,2& 3");
	}
	}
	 do {
			System.out.println(" do you want to continue? Y=yes|N=no");
		    scanner=new Scanner(System.in);
		    value = scanner.nextLine();
		    if (value.equalsIgnoreCase("y")|| value.equalsIgnoreCase("n")) {
		    	choice = false;
		    }

			else {
				System.err.println("Invalid Input!! Enter Y or N");
				choice= true;
			}
		} while (choice);
	   }while(value.equalsIgnoreCase("y"));
	   System.out.println("thank you for visiting");
	}
}  
	
	

	
	
	
	
	
	
	
	
	
	
	
	


