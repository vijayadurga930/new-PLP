package com.cg.mobshop.dto;

public class Mobiles implements  Comparable <Mobiles> {
private int mobileId;
private String name;

private int quantity ;
private double price;
/**
 * writing bean class for mobile sgop details
 */

@Override
public String toString() {
	return "   " + mobileId + "    " + name + "   " + quantity + "   " + price + " " +"\n";
}


public int getMobileId() {
	return mobileId;
}


public void setMobileId(int mobileId) {
	this.mobileId = mobileId;
}


public String getName() {
	return name;
}


public void setName(String name) {
	this.name = name;
}


public int getQuantity() {
	return quantity;
}


public void setQuantity(int quantity) {
	this.quantity = quantity;
}


public double getPrice() {
	return price;
}


public void setPrice(double price) {
	this.price = price;
}


public Mobiles(int mobileId, String name, int quantity, double price) {
	super();
	this.mobileId = mobileId;
	this.name = name;
	this.quantity = quantity;
	this.price = price;
}


public Mobiles() {
	super();
	// TODO Auto-generated constructor stub
}


@Override
public int compareTo(Mobiles m) {
	if(this.mobileId>m.mobileId)
		return 1;
	else if(this.mobileId<m.mobileId)
		return -1;
	else 
		return 0;
	
	
}
}
