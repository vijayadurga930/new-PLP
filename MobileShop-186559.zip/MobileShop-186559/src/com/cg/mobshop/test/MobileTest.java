package com.cg.mobshop.test;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.List;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import com.cg.mobshop.dao.MobileDAO;
import com.cg.mobshop.dao.MobileDAOImpl;
import com.cg.mobshop.dto.Mobiles;
/**
 * 
 * @author vijsimha writing test cases for mobiledaoimplements
 *
 */

public class MobileTest {
 Mobiles mobiles= new Mobiles(0,"sony",5,1000);
 MobileDAO dao=new MobileDAOImpl();
 static List<Mobiles> list=null;
	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		list=new ArrayList<>();
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
		
	}

	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testgetAllDetails() {
		
		assertNotEquals(dao.getAllDetails(), true);
		
		
	}
	@Test
	public void testgetAllDetails1() {
		
		assertNotSame(dao.getAllDetails(), true);
		
	}
	@Test
	public void testgetAllDetails2() {
		
		assertNotNull(dao.getAllDetails());
		
	}
	@Test
	public void testgetNewDetails1() {
		
		assertNotEquals(dao.getNewDetails(0), true);
		
		
	}
	@Test
	public void testgetNewDetails2() {
		assertNotSame(dao.getNewDetails(0), true);
		
	}
	@Test
	public void testgetNewDetails3() {
		assertNotNull(dao.getNewDetails(0));
		
	}
	@Test
	public void testDeleteMobile() {
		boolean status1=dao.deleteMobile(101);
		boolean status2=dao.deleteMobile(100);
		System.out.println(status1);
		assertNotEquals(status2, true);
		assertNotSame(status2, true);
		assertNotNull(dao.deleteMobile(0));
	
		assertFalse(status2);
		
		
		
	}

}
