package com.bank.main;

public class  InvalidException extends Exception {
public InvalidException(String msg){
	System.out.println(msg);
}
}
