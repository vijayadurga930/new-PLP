package com.bank.service;

import com.bank.dao.BankDAO;
import com.bank.entity.BankDetails;
import com.bank.entity.TransactionDetails;

public class BankService implements BankServiceInterface {
 BankDAO dao=new BankDAO();
 
	@Override
	
	public BankDetails getAccountById(int id) {
	BankDetails bank  = dao.getAccountById(id) ;
		return bank;
	}

	@Override
	public void CreateAccount(BankDetails bank) {
		dao.beginTransaction();
		dao.CreateAccount(bank);
		dao.commitTransaction();
	}

	@Override
	public void ShowBalance(BankDetails bank) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void Deposit(BankDetails bank) {
		dao.beginTransaction();
		dao.Deposit(bank);	
		dao.commitTransaction();
 
	}

	@Override
	public void Withdraw(BankDetails bank) {
		dao.beginTransaction();
		dao.Withdraw(bank);
		dao.commitTransaction();
	}

	@Override
	public void PrintTransactions(int id) {
		 dao.PrintTransactions(id);
		
	}

	@Override
	public void commitTransaction() {
	dao.commitTransaction();
		
	}

	@Override
	public void beginTransaction() {
		dao.beginTransaction();
	}

	public void addTransaction(TransactionDetails trans) {

	dao.beginTransaction();
	dao.addTransaction(trans);
	dao.commitTransaction();
	}
	 
}

