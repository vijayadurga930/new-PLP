package com.cg.banktest;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import com.cg.beans.Customer;
import com.cg.beans.Transaction;
import com.cg.dao.BankdaoImpl;
import com.cg.dao.IBankdao;
import com.cg.exception.BankException;

public class BankDaoTest {
	static IBankdao dao;
	static Customer customer;
	static Transaction transaction;
	
	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		dao = new BankdaoImpl();
		customer = new Customer();
		transaction = new Transaction();	
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
		dao = null;
		customer = null;
		transaction = null;

	}
	

	@Before
	public void setUp() throws Exception {
		customer = new Customer(123,"Vijaya","9912847538","vijaya@gmail.com", 98989898,556774.7, null);

		
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testAddToCustomer() {
		assertNotNull(customer);

	}
	@Test
	public void testGetCustomerList() throws BankException {
		dao.customerList.clear();
		double custId= dao.addToCustomer(customer);
		assertNotEquals(1,dao.customerList.size()>1);
	}


}
