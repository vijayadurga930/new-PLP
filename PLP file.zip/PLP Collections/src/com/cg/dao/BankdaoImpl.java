package com.cg.dao;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

import com.cg.beans.Customer;
import com.cg.beans.Transaction;
import com.cg.exception.BankException;

public class BankdaoImpl implements IBankdao{


	public static Map<Integer, Customer> customerList = new HashMap<>();
	public static Map<Integer, Transaction> transactionList = new HashMap<>();
	
	
	
	public double addToCustomer(Customer customer) {
		int custId =(int) (Math.random()*10000);
		double accountNo = (long) (Math.random()*100000000L);
		customer.setCustid(custId);
		customer.setAccountnum(accountNo);
		getCustomerList().put(custId, customer);
		System.out.println("Your CustId is:"+ custId);
		return accountNo;
		
	}

	public static Map<Integer, Customer> getCustomerList() {
		return customerList;
	}
	public static void setCustomerList(Map<Integer, Customer> customerList) {
		BankdaoImpl.customerList = customerList;
	}
	public static Map<Integer,Transaction> gettransactionList() {
		return transactionList;
	}
	public static void settransactionList(Map<Integer, Transaction> transactionList) {
		BankdaoImpl.transactionList = transactionList;
	}




	@Override
	public void depositBalance(int custId, double amount) throws BankException {


		Customer customer= BankdaoImpl.customerList.get(custId);
		Set keys= customerList.keySet();
		Iterator iterator =keys.iterator();
		while(iterator.hasNext()){
			int key = (int) iterator.next();
			if( key == custId) {
				double balance = customer.getBalance()+amount;
				customer.setBalance(balance);
				System.out.println("Balance Succefully deposited!!Your available balance is:"+balance);
				
			}
		}
	}

	@Override
	public void withdrawBalance(int custId, double amount) throws BankException {
		Customer customer= BankdaoImpl.customerList.get(custId);
		Set keys= customerList.keySet();
		Iterator iterator =keys.iterator();
		while(iterator.hasNext()){
			int key = (int) iterator.next();
			if( key == custId) {
				double balance = customer.getBalance()-amount;
				customer.setBalance(balance);
				
				System.out.println("Transaction Succesfull!!Your available balance is:"+balance);
			}
	}
		
	}

	@Override
	public Map<Integer, Transaction> printTransactionDetails(int transId) throws BankException {
		// TODO Auto-generated method stub
		return BankdaoImpl.gettransactionList();
	}

	@Override
	public double showBalance(int custId) throws BankException {
		Customer customer= BankdaoImpl.customerList.get(custId);
		double balance = 0;
		Set keys= customerList.keySet();
		Iterator iterator =keys.iterator();
		while(iterator.hasNext()){
			int key = (int) iterator.next();
			if( key == custId) {
				 balance = customer.getBalance();
				System.out.println("Your available balance is:"+balance);
			}
	}
		return balance;
	}
	
	}

	
	

