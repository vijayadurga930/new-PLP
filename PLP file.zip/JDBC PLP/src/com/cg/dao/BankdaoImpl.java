package com.cg.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import com.cg.beans.Customer;
import com.cg.beans.Transaction;
import com.cg.exception.BankException;
import com.cg.utility.DBConnection;

public class BankdaoImpl implements IBankdao{
	public static Map<Integer, Customer> customerList = new HashMap<>();
	public static Map<Integer, Transaction> transactionList = new HashMap<>();
	
	Connection connection = null;
	PreparedStatement statement = null;
	ResultSet resultSet = null;
	int row = -1;
	int authorId = 0;
	static boolean status=false;
	List<Transaction> transList=null;
	
	
	
	
	@Override
	public void createTable(String accountNo)
	{
		try(Connection connection = DBConnection.getConnection();) {
			
			statement=connection.prepareStatement("create table "+accountNo+" (TId number(10) primary key,"
					+ ""+"Trans_Type varchar2(20),"+ " "+"Balance Number(10),"
					+ " "+"Amount Number(10),"+"Transaction_Date varchar2(20)");
			status=statement.execute();
			System.out.println("Transaction Sheet Opened");
		} catch (SQLException e) {
			System.out.println(e.getMessage());
		}
	}
	
	public boolean insertToTransaction(Transaction tran, int transactId,String AccountNum) {
		try (Connection connection = DBConnection.getConnection();) {
			statement = connection.prepareStatement("insert into "+ AccountNum +" values (?,?,?,?,?)");
			System.out.println(tran.getTransid());
			statement.setInt(1, tran.getTransid());
			statement.setString(2, tran.getTranstype());
			statement.setLong(3, tran.getTransaccountnum());
			
			statement.setString(4, tran.getTransdate());
			statement.setInt(5, tran.getCustid());
			statement.setLong(6, tran.getAccountnum());
			statement.setDouble(7, tran.getAmount());
			
			
			row = statement.executeUpdate();
			return true;
		} catch (SQLException e) {
			System.out.println(e.getMessage());
		}
		return false;
	}
	
	
	@Override
	public boolean insertIntoBanking(Customer customer)
	{ 
		try (Connection connection = DBConnection.getConnection();)
		{
		
			statement = connection.prepareStatement("insert into Banking values(?,?,?,?,?,?,?)");			
			statement.setInt(1,customer.getCustid());
			statement.setString(2,customer.getName());
			statement.setString(3,customer.getPhone());
			statement.setString(4, customer.getMail());
			statement.setDouble(5,customer.getAccountnum());
			statement.setDouble(7,customer.getBalance());
			
			
			row = statement.executeUpdate();
			return true;
		} catch (SQLException e) {
			System.out.println(e.getMessage());
		}
		return false;
	}
	
	@Override
	public List<Transaction> getAllTransaction(String AccountNum)
	{       transList= new ArrayList<>();
		try (Connection connection = DBConnection.getConnection();) {
			statement = connection.prepareStatement("select * from "+AccountNum);
System.out.println("select * from "+AccountNum);
			resultSet = statement.executeQuery();
			while (resultSet.next()) {
				Transaction trans = new Transaction();
				trans.setTransid(resultSet.getInt("TID"));
				trans.setTranstype(resultSet.getString("Trans_Type"));
				trans.setAmount(resultSet.getDouble("Amount"));
			     trans.setBalance(resultSet.getDouble("Balance"));
				trans.setTransdate(resultSet.getString("Transaction_Date"));
			
				transList.add(trans);
			}
			
		} catch (SQLException e) {
			System.out.println(e.getMessage());
		}
		
		return transList;		
	}

	@Override
	public double balance(String accountNum) {
		try (Connection connection = DBConnection.getConnection();) {
			statement = connection.prepareStatement("select  balance from  Banking where AccountNO ='"+accountNum+"'");
			resultSet = statement.executeQuery();
			while (resultSet.next()) {
			return resultSet.getDouble("Balance");
			}				
		} catch (SQLException e) {
			e.printStackTrace();
		}	
		return 0;
	}

	@Override
	public void updateBalance(double balance, String accountNum) {
		try (Connection connection = DBConnection.getConnection();) {
			statement = connection.prepareStatement("update Banking  set balance= "+balance+"where AccountNO ='"+accountNum+"'");
			resultSet = statement.executeQuery();	
		} catch (SQLException e) {
			e.printStackTrace();
		}	
	}

	
	

	
	public double addToCustomer(Customer customer) {
		int custId =(int) (Math.random()*10000);
		double accountNo = (long) (Math.random()*100000000L);
		customer.setCustid(custId);
		customer.setAccountnum(accountNo);
		getCustomerList().put(custId, customer);
		System.out.println("Your CustId is:"+ custId);
		return accountNo;
		
	}

	public static Map<Integer, Customer> getCustomerList() {
		return customerList;
	}
	public static void setCustomerList(Map<Integer, Customer> customerList) {
		BankdaoImpl.customerList = customerList;
	}
	public static Map<Integer,Transaction> gettransactionList() {
		return transactionList;
	}
	public static void settransactionList(Map<Integer, Transaction> transactionList) {
		BankdaoImpl.transactionList = transactionList;
	}




	@Override
	public void depositBalance(int custId, double amount) throws BankException {


		Customer customer= BankdaoImpl.customerList.get(custId);
		Set keys= customerList.keySet();
		Iterator iterator =keys.iterator();
		while(iterator.hasNext()){
			int key = (int) iterator.next();
			if( key == custId) {
				double balance = customer.getBalance()+amount;
				customer.setBalance(balance);
				System.out.println("Balance Succefully deposited!!Your available balance is:"+balance);
				
			}
		}
	}

	@Override
	public void withdrawBalance(int custId, double amount) throws BankException {
		Customer customer= BankdaoImpl.customerList.get(custId);
		Set keys= customerList.keySet();
		Iterator iterator =keys.iterator();
		while(iterator.hasNext()){
			int key = (int) iterator.next();
			if( key == custId) {
				double balance = customer.getBalance()-amount;
				customer.setBalance(balance);
				
				System.out.println("Transaction Succesfull!!Your available balance is:"+balance);
			}
	}
		
	}

	@Override
	public Map<Integer, Transaction> printTransactionDetails(int transId) throws BankException {
		// TODO Auto-generated method stub
		return BankdaoImpl.gettransactionList();
	}

	@Override
	public double showBalance(int custId) throws BankException {
		Customer customer= BankdaoImpl.customerList.get(custId);
		double balance = 0;
		Set keys= customerList.keySet();
		Iterator iterator =keys.iterator();
		while(iterator.hasNext()){
			int key = (int) iterator.next();
			if( key == custId) {
				 balance = customer.getBalance();
				System.out.println("Your available balance is:"+balance);
			}
	}
		return balance;
	}


}
