package com.cg.dao;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.cg.beans.Customer;
import com.cg.beans.Transaction;
import com.cg.exception.BankException;

public interface IBankdao {
public static Map<Integer, Customer> customerList = new HashMap<>();

boolean insertIntoBanking(Customer customer);


	

	double showBalance(int custId) throws BankException;

	void depositBalance(int custId, double amount) throws BankException;

	void withdrawBalance(int custId, double amount) throws BankException;

	 public Map<Integer, Transaction> printTransactionDetails(int transId) throws BankException;

	double addToCustomer(Customer customer)throws BankException;

	void createTable(String accountNum);

	boolean insertToTransaction(Transaction tran, int transactId, String AccountNum);

	
	List<Transaction> getAllTransaction(String AccountNum);

	double balance(String accountNum);

	void updateBalance(double balance, String accountNo);
}
