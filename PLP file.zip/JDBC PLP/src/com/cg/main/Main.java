package com.cg.main;

import java.util.InputMismatchException;
import java.util.Scanner;

import com.cg.beans.Customer;
import com.cg.exception.BankException;
import com.cg.service.BankServiceImpl;

import com.cg.service.IBankservice;

public class Main {

	public static void main(String[] args) {
		

		String continueChoice;
		boolean continueValue = false;

		Scanner scanner = null;
		do {

			System.out.println(" Banking App");
			System.out.println("1.Create account\n 2.Show Balance\n"
					+ "3.Deposit\n4.Withdraw\n5.Print Transactions\n6.exit");
			
			IBankservice service = new BankServiceImpl();

			int choice ;
			boolean choiceFlag = false;

			do {
				scanner = new Scanner(System.in);
				System.out.println("choose the option from the above services::");
				try {
					choice = scanner.nextInt();
					choiceFlag = true;

					boolean nameFlag = false;

					String name ;
					switch (choice) {

					case 1:
						do {
							scanner = new Scanner(System.in);
							System.out.println("Enter Customer name:");
							name = scanner.nextLine();
							try {
								service.isNameValidate(name);
								nameFlag = true;
							} catch (BankException e) {
								nameFlag = false;
								System.err.println(e.getMessage());
							}
						} while (!nameFlag);

						String phone;
						boolean phoneFlag = false;
						do {
							scanner = new Scanner(System.in);
							System.out.println("Enter mobile :");
							try {
								phone = scanner.nextLine();
								service.isPhoneValidate(phone);
								phoneFlag = true;
							} catch (InputMismatchException e) {
								phoneFlag = false;
								System.err.println("Cost should be in digits");
							} catch (BankException e) {
								phoneFlag = false;
								System.err.println(e.getMessage());
							}
						} while (!phoneFlag);

						String email;
						boolean emailFlag = false;
						do {
							scanner = new Scanner(System.in);
							System.out.println("Enter email :");
							try {
								email = scanner.nextLine();
								service.isMailValidate(email);
								emailFlag = true;
							} catch (InputMismatchException e) {
								emailFlag = false;
								System.err.println("your entered format must be an email format");
							} catch (BankException e) {
								emailFlag = false;
								System.err.println(e.getMessage());
							}
						} while (!emailFlag);

						System.out.println("Enter customer address:");
						String address = scanner.nextLine();
						 String accountnum;
						double balance;
						int id;
						Customer customer = new Customer();
						try {
							double accountNo = service.addToCustomer(customer);
							System.out.println("Your accountNo is " + accountNo);
						} catch (BankException e) {
							System.err.println(e.getMessage());
						}

						break;
					case 2: {

						boolean custFlag = false;
						double balancecheck;
						do {
							scanner = new Scanner(System.in);
							System.out.println("Enter custId to check balance:");
							int custId=scanner.nextInt();
							try {
								custFlag=service.isValidcustomerId(custId);
							} catch (BankException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}
							 try {
								double showbalance=service.BalanceEnquiry(custId);
							} catch (BankException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}
						} while (!custFlag);

						break;
					}
					case 3: {

						boolean custFlag = false;
						do {
							scanner = new Scanner(System.in);
							System.out.println("Enter custId to deposit balance:");
							int custId=scanner.nextInt();
							try {
								custFlag=service.isValidcustomerId(custId);
							} catch (BankException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}

	                  	System.out.println(" enter amount to deposit:");
	                      	scanner = new Scanner(System.in);
							double amount=scanner.nextDouble();
							try 
							{
							    service.depositBalance(custId, amount);
							}catch (BankException e){
								e.printStackTrace();
							}
							
						} while (!custFlag);	
					}break;

					case 4: {

						boolean custFlag = false;
						do {
							scanner = new Scanner(System.in);
							System.out.println("Enter custId to withdraw balance:");
							int custId=scanner.nextInt();
							try {
								custFlag=service.isValidcustomerId(custId);
							} catch (BankException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}
							System.out.println(" enter amount to deposit:");
	                      	scanner = new Scanner(System.in);
							double amount=scanner.nextDouble();
							try {
								service.withdrawBalance(custId, amount);
							} catch (BankException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}
						} while (!custFlag);
						break;
					}

					case 5: {

						boolean custFlag = false;
						do {
							scanner = new Scanner(System.in);
							System.out.println("Enter Destination customer Id to send money:");
							int Transid=scanner.nextInt();
							System.out.println("enter the method to send money:");
							String Transtype=scanner.nextLine();
							
 /* int transId= service.transferFunds(transaction, sourceCustId, destinationCustId);
*/								System.out.println("Succesfull transaction with transaction Id:"+Transid);
							break;
						} while (!custFlag);

						break;
					}

			case 6:{
						System.out.println("Thank u, visit again");
						System.exit(0);
			}break;
					default:
						System.out.println("invalid input....");
						choiceFlag = false;
						break;
					}

				} catch (InputMismatchException exception) {
					choiceFlag = false;
					System.err.println("input should contain only digits");
				}
			} while (!choiceFlag);

			do {
				scanner = new Scanner(System.in);
				System.out.println("do you want to continue again [yes/no]");
				continueChoice = scanner.nextLine();
				if (continueChoice.equalsIgnoreCase("yes")) {
					continueValue = true;
					break;
				} else if (continueChoice.equalsIgnoreCase("no")) {
					System.out.println("thank you");
					continueValue = false;
					break;
				} else {
					System.out.println("enter yes or no");
					continueValue = false;
					continue;
				}
			} while (!continueValue);

		} while (continueValue);
		scanner.close();

	
		
}


}
