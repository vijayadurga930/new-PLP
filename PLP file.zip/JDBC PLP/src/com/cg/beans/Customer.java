package com.cg.beans;

import java.util.List;

public class Customer {

	
	private int custid;
	private String name;
    private String phone;
	private String mail;
	private double accountnum;
	private double balance;
	private List<Transaction> transactions;
	public Customer() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Customer(int custid, String name, String phone, String mail, double accountnum, double balance,
			List<Transaction> transactions) {
		super();
		this.custid = custid;
		this.name = name;
		this.phone = phone;
		this.mail = mail;
		this.accountnum = accountnum;
		this.balance = balance;
		this.transactions = transactions;
	}
	public int getCustid() {
		return custid;
	}
	public void setCustid(int custid) {
		this.custid = custid;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public String getMail() {
		return mail;
	}
	public void setMail(String mail) {
		this.mail = mail;
	}
	public double getAccountnum() {
		return accountnum;
	}
	public void setAccountnum(double accountNo) {
		this.accountnum = accountNo;
	}
	public double getBalance() {
		return balance;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}
	public List<Transaction> getTransactions() {
		return transactions;
	}
	public void setTransactions(List<Transaction> transactions) {
		this.transactions = transactions;
	}
	@Override
	public String toString() {
		return "Customer [custid=" + custid + ", name=" + name + ", phone=" + phone + ", mail=" + mail + ", accountnum="
				+ accountnum + ", balance=" + balance + ", transactions=" + transactions + "]";
	}

	
	
}
