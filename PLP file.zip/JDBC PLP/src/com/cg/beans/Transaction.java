package com.cg.beans;

import java.util.Date;

public class Transaction {

	
	private int transid;
	private String transtype;
	private long transaccountnum;
	private String transdate;
	private int custid;
	private long accountnum;
	private double amount;
	private double balance;

	public Transaction(int transid, String transtype, long transaccountnum, String transdate, int custid, long accountnum,
			double amount,double balance) {
		super();
		this.transid = transid;
		this.transtype = transtype;
		this.transaccountnum = transaccountnum;
		this.transdate = transdate;
		this.custid = custid;
		this.accountnum = accountnum;
		this.amount = amount;
		this.balance=balance;
	}
	
	public double getBalance() {
		return balance;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}
	public Transaction() {
		super();
		// TODO Auto-generated constructor stub
	}
	public int getTransid() {
		return transid;
	}
	public void setTransid(int transid) {
		this.transid = transid;
	}
	public String getTranstype() {
		return transtype;
	}
	public void setTranstype(String transtype) {
		this.transtype = transtype;
	}
	public long getTransaccountnum() {
		return transaccountnum;
	}
	public void setTransaccountnum(long transaccountnum) {
		this.transaccountnum = transaccountnum;
	}
	public String getTransdate() {
		return transdate;
	}
	public void setTransdate(String transdate) {
		this.transdate = transdate;
	}
	public int getCustid() {
		return custid;
	}
	public void setCustid(int custid) {
		this.custid = custid;
	}
	public long getAccountnum() {
		return accountnum;
	}
	public void setAccountnum(long accountnum) {
		this.accountnum = accountnum;
	}
	public double getAmount() {
		return amount;
	}
	public void setAmount(double amount) {
		this.amount = amount;
	}
	@Override
	public String toString() {
		return "Transaction [transid=" + transid + ", transtype=" + transtype + ", transaccountnum=" + transaccountnum
				+ ", transdate=" + transdate + ", custid=" + custid + ", accountnum=" + accountnum + ", amount="
				+ amount + "]";
	}
	
	

}
