package com.cg.service;

import java.util.Map;
import java.util.regex.Pattern;

import com.cg.beans.Customer;
import com.cg.beans.Transaction;
import com.cg.dao.BankdaoImpl;
import com.cg.dao.IBankdao;
import com.cg.exception.BankException;

public class BankServiceImpl implements IBankservice{

	IBankdao dao=new BankdaoImpl();
	
	
	@Override
	public boolean isNameValidate(String name) throws BankException {
		boolean resultNameFlag=false;
		String nameRegex="[A-Z]{1}[a-z]{5}$";
		if(!Pattern.matches(nameRegex, name)) {
			resultNameFlag = false;
			throw new BankException("Customer Name should start with capital ");
		}
		else {
			resultNameFlag = true;
		}
		return resultNameFlag;
		
	}

	@Override
	public boolean isPhoneValidate(String phone) throws BankException {
		boolean resultMobFlag= false;
		String mobRegex ="[6,7,8,9]{1}[0-9]{9}$";
		if(!Pattern.matches(mobRegex, phone)) {
			throw new BankException("Mobile no should start with 7,8,9 and should be 10 digit");
		}
		else {
			resultMobFlag= true;
		}
		return resultMobFlag;
	}

	
	@Override
	public boolean isMailValidate(String mail) throws BankException {
		boolean resultEmailFlag= false;
		String emailRegex="^[a-z]{5,}@[a-z]{3,}.com$";
		if(!Pattern.matches(emailRegex, mail)){
			throw new BankException("Email should be in small case end with '.com' ");
		}
		else {
			resultEmailFlag= true;
		}
		return resultEmailFlag;
	}


	



	@Override
	public boolean isValidcustomerId(int custId) throws BankException {
		
		boolean flag = false;
		Customer customer = BankdaoImpl.getCustomerList().get(custId);
		if(customer!= null) {
			flag = true;
		
		}
		else {
			flag= false;
			throw new BankException("Entered customer id is invalid");
		}
		return flag;
	}


	@Override
	public void depositBalance(int custId, double amount) throws BankException {
		
		dao.depositBalance(custId,amount);

	}

	@Override
	public void withdrawBalance(int custId, double amount) throws BankException {
		
		dao.withdrawBalance(custId,amount);

	}

	@Override
	public boolean validateTransactionId(int transId) throws BankException {
		boolean flag = false;
		Transaction transaction = BankdaoImpl.transactionList.get(transId);
		if(transaction!= null) {
			flag = true;
		
		}
		else {
			flag= false;
			throw new BankException("Entered transaction id is invalid");
			}
		return flag;
		
	}

	@Override
	public Map<Integer, Transaction> printTransactionDetails(int transId) throws BankException {
		return dao.printTransactionDetails(transId);  
			
	}

	@Override
	public double addToCustomer(Customer customer) throws BankException {
		return dao.addToCustomer(customer);
	}

	@Override
	public double BalanceEnquiry(int custId) throws BankException {
		return  dao.showBalance(custId);
			}

	@Override
	public double balance(String accountNo) {
	double	balance= dao.balance(accountNo);
		return balance;
	

	}

}
