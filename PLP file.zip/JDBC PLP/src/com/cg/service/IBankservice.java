package com.cg.service;

import java.util.Map;

import com.cg.beans.Customer;
import com.cg.beans.Transaction;
import com.cg.exception.BankException;

public interface IBankservice {
	boolean isNameValidate(String name) throws BankException;

	boolean isPhoneValidate(String phone)throws BankException;

	boolean  isMailValidate(String mail)throws BankException;

	double addToCustomer(Customer customer)throws BankException;


	boolean isValidcustomerId(int custId)throws BankException;

	double BalanceEnquiry(int custId)throws BankException;

	void depositBalance(int custId, double amount)throws BankException;

	void withdrawBalance(int custId, double amount)throws BankException;

	boolean validateTransactionId(int transId) throws BankException ;

	Map<Integer, Transaction> printTransactionDetails(int transId)throws BankException;

	double balance(String accountNo);





}
